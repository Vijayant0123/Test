export class Medicine {
  name: string;
  brand: string;
  price: number;
  quantity: number;
  expiryDate: Date;
  note: string;
}

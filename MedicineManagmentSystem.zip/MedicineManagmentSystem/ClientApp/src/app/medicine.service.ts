import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Medicine } from './Models/medicine';
import { Observable } from 'rxjs';


const baseurl = "http://localhost:50185/api/Medicine";


@Injectable({
  providedIn: 'root'
})
export class MedicineService {

  constructor(private httpClient: HttpClient) { }

  getMedicines(): Observable<Medicine[]> {
    return this.httpClient.get<Medicine[]>(`${baseurl}`);
  }

  getMedicine(name:string): Observable<Medicine> {
    return this.httpClient.get<Medicine>(`${baseurl}/${name}`);
  }

  addMedicine(medicine: Medicine): Observable<Medicine> {
    return this.httpClient.post<Medicine>(`${baseurl}`, medicine);
  }

  updateMedicine(medicine: Medicine): Observable<Medicine> {
    return this.httpClient.put<Medicine>(`${baseurl}/${medicine.name}`, medicine);
  }

  deleteMedicine(medicine: Medicine) {
    return this.httpClient.delete(`${baseurl}/${medicine.name}`);
  }

}
